require "/scripts/augments/item.lua"

function apply(input)
  local output = Item.new(input)
   if root.itemConfig(output.name).config.r_techArmor then output:setInstanceValue("r_techActive", not output:instanceValue("r_techActive"))
   return output:descriptor(), 0 end
end
