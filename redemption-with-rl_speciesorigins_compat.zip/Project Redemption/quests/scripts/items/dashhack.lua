require "/scripts/util.lua"
require "/quests/scripts/questutil.lua"
require("/quests/scripts/portraits.lua")

function init()
  sb.logInfo("body store: %s",storage.bdtechStored)
  self.radioMessages = config.getParameter("radioMessages")
  storage.bdtechStored = storage.bdtechStored or player.equippedTech("body")
  storage.bdtechEquipped = storage.bdtechEquipped or false
  storage.bditem = storage.bditem or false
  storage.bdtimer = storage.bdtimer or 0
  storage.bdtechSwapped = storage.bdtechSwapped or false
  storage.bddebug = config.getParameter("debug") or false
  message.setHandler("techChangeOnBD", function(...) onTechChangeEquippedBD(...) end)
  --message.setHandler("techChangeOff", function(...) onTechChangeOff(...) end)

end

function onTechChangeEquippedBD(message, isLocal, techName)
	local eqTech = player.equippedTech("body")
	if eqTech ~= techName then
		storage.bdtechStored = player.equippedTech("body") or false --just for legs right now. hopefully this works
		storage.bdtechEquipped = techName
		storage.bditem = player.equippedItem("chest").name
		if storage.bddebug then
			local messageTemp = self.radioMessages.received
			messageTemp.text="Activated Tech "..techName.." ( replaced "..storage.bdtechStored.." ) on "..storage.bditem
			player.radioMessage(messageTemp)
		end
		player.makeTechAvailable(techName)
		player.enableTech(techName)
		player.equipTech(techName)
		storage.bdtechSwapped = true
	elseif storage.bddebug then
		local messageTemp = self.radioMessages.received
		messageTemp.text="Duplicate launch detected, attempted to treat tech ".. techName.." as replaced tech ("..storage.bdtechStored..")"
		player.radioMessage(messageTemp)
	end
end

--[[function onTechChangeOff(message, isLocal, ...)
	player.equipTech(storage.bdtechStored)
	local messageTemp = self.radioMessages.received
	messageTemp.text="Item "..storage.bditem.." removed. Restoring tech "..storage.bdtechStored
	player.radioMessage(messageTemp)
end]]--

function questStart()
	storage.bdtimer = 0
	storage.bdtechEquipped = false
	
end

function questComplete()
	questutil.questCompleteActions()
end

function update(dt)
	local itemTemp = ""
	if player.equippedItem("chest") then
		itemTemp = player.equippedItem("chest").name
	end
	if storage.bdtechEquipped and storage.bditem then --don't want it to die while waiting for the message
		if itemTemp ~= storage.bditem then --check if player is still wearing the item
			if storage.bdtechSwapped then
				if storage.bdtechStored then
					player.equipTech(storage.bdtechStored)
				end
				player.makeTechUnavailable(storage.bdtechEquipped)
				if storage.bddebug then
					local messageTemp = self.radioMessages.received
					messageTemp.text="Item "..storage.bditem.." removed. Restoring tech "..storage.bdtechStored
					player.radioMessage(messageTemp)
				end
				storage.bdtechSwapped = false
			end
		elseif not player.hasItem({name = storage.bditem}) then --check if player HAS the item at all
			quest.complete()
		elseif player.equippedTech("body") ~= storage.bdtechEquipped and storage.bdtechSwapped then --if the tech changed, assume player kinda wants it to change when they take the item off
			storage.bdtechStored = player.equippedTech("body")
			player.equipTech(storage.bdtechEquipped)
		end
	end
	--[[elseif storage.bdtimer < 120 then --just in case. hope message arrives faster than that.
		storage.bdtimer = storage.bdtimer + dt
	else
		quest.complete()
	end
	quest.setProgress(math.min(1.0,(storage.bdtimer/120)))]]--
end