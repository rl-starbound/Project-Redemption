require "/scripts/util.lua"
require "/quests/scripts/questutil.lua"
require("/quests/scripts/portraits.lua")

function init()
  sb.logInfo("head store: %s",storage.hdtechStored)
  self.radioMessages = config.getParameter("radioMessages")
  storage.hdtechStored = storage.hdtechStored or player.equippedTech("head")
  storage.hdtechEquipped = storage.hdtechEquipped or false
  storage.hditem = storage.hditem or false
  storage.hdtimer = storage.hdtimer or 0
  storage.hdtechSwapped = storage.hdtechSwapped or false
  storage.hddebug = config.getParameter("debug") or false
  message.setHandler("techChangeOnHD", function(...) onTechChangeEquippedHD(...) end)
  --message.setHandler("techChangeOff", function(...) onTechChangeOff(...) end)

end

function onTechChangeEquippedHD(message, isLocal, techName)
	local eqTech = player.equippedTech("head")
	if eqTech ~= techName then
		storage.hdtechStored = player.equippedTech("head") or false --just for legs right now. hopefully this works
		storage.hdtechEquipped = techName
		storage.hditem = player.equippedItem("head").name
		if storage.hddebug then
			local messageTemp = self.radioMessages.received
			messageTemp.text="Activated Tech "..techName.." ( replaced "..storage.hdtechStored.." ) on "..storage.hditem
			player.radioMessage(messageTemp)
		end
		player.makeTechAvailable(techName)
		player.enableTech(techName)
		player.equipTech(techName)
		storage.hdtechSwapped = true
	elseif storage.hddebug then
		local messageTemp = self.radioMessages.received
		messageTemp.text="Duplicate launch detected, attempted to treat tech ".. techName.." as replaced tech ("..storage.hdtechStored..")"
		player.radioMessage(messageTemp)
	end
end

--[[function onTechChangeOff(message, isLocal, ...)
	player.equipTech(storage.hdtechStored)
	local messageTemp = self.radioMessages.received
	messageTemp.text="Item "..storage.hditem.." removed. Restoring tech "..storage.hdtechStored
	player.radioMessage(messageTemp)
end]]--

function questStart()
	storage.hdtimer = 0
	storage.hdtechEquipped = false
	
end

function questComplete()
	questutil.questCompleteActions()
end

function update(dt)
	local itemTemp = ""
	if player.equippedItem("head") then
		itemTemp = player.equippedItem("head").name
	end
	if storage.hdtechEquipped and storage.hditem then --don't want it to die while waiting for the message
		if itemTemp ~= storage.hditem then --check if player is still wearing the item
			if storage.hdtechSwapped then
				if storage.hdtechStored then
					player.equipTech(storage.hdtechStored)
				end
				player.makeTechUnavailable(storage.hdtechEquipped)
				if storage.hddebug then
					local messageTemp = self.radioMessages.received
					messageTemp.text="Item "..storage.hditem.." removed. Restoring tech "..storage.hdtechStored
					player.radioMessage(messageTemp)
				end
				storage.hdtechSwapped = false
			end
		elseif not player.hasItem({name = storage.hditem}) then --check if player HAS the item at all
			quest.complete()
		elseif player.equippedTech("head") ~= storage.hdtechEquipped and storage.hdtechSwapped then --if the tech changed, assume player kinda wants it to change when they take the item off
			storage.hdtechStored = player.equippedTech("head")
			player.equipTech(storage.hdtechEquipped)
		end
	end
	--[[elseif storage.hdtimer < 120 then --just in case. hope message arrives faster than that.
		storage.hdtimer = storage.hdtimer + dt
	else
		quest.complete()
	end
	quest.setProgress(math.min(1.0,(storage.hdtimer/120)))]]--
end