require "/scripts/util.lua"
require "/quests/scripts/questutil.lua"
require("/quests/scripts/portraits.lua")

function init()
  sb.logInfo("legs store: %s",storage.lgtechStored)
  self.radioMessages = config.getParameter("radioMessages")
  storage.lgtechStored = storage.lgtechStored or player.equippedTech("legs")
  storage.lgtechEquipped = storage.lgtechEquipped or false
  storage.lgitem = storage.lgitem or false
  storage.lgtimer = storage.lgtimer or 0
  storage.lgtechSwapped = storage.lgtechSwapped or false
  storage.lgdebug = config.getParameter("debug") or false
  message.setHandler("techChangeOnLG", function(...) onTechChangeEquippedLG(...) end)
  --message.setHandler("techChangeOff", function(...) onTechChangeOff(...) end)

end

function onTechChangeEquippedLG(message, isLocal, techName)
	local eqTech = player.equippedTech("legs")
	if eqTech ~= techName then
		storage.lgtechStored = player.equippedTech("legs") or false --just for legs right now. hopefully this works
		storage.lgtechEquipped = techName
		storage.lgitem = player.equippedItem("legs").name
		if storage.lgdebug then
			local messageTemp = self.radioMessages.received
			messageTemp.text="Activated Tech "..techName.." ( replaced "..storage.lgtechStored.." ) on "..storage.lgitem
			player.radioMessage(messageTemp)
		end
		player.makeTechAvailable(techName)
		player.enableTech(techName)
		player.equipTech(techName)
		storage.lgtechSwapped = true
	elseif storage.lgdebug then
		local messageTemp = self.radioMessages.received
		messageTemp.text="Duplicate launch detected, attempted to treat tech ".. techName.." as replaced tech ("..storage.lgtechStored..")"
		player.radioMessage(messageTemp)
	end
end

--[[function onTechChangeOff(message, isLocal, ...)
	player.equipTech(storage.lgtechStored)
	local messageTemp = self.radioMessages.received
	messageTemp.text="Item "..storage.lgitem.." removed. Restoring tech "..storage.lgtechStored
	player.radioMessage(messageTemp)
end]]--

function questStart()
	storage.lgtimer = 0
	storage.lgtechEquipped = false
	
end

function questComplete()
	questutil.questCompleteActions()
end

function update(dt)
	local itemTemp = ""
	if player.equippedItem("legs") then
		itemTemp = player.equippedItem("legs").name
	end
	if storage.lgtechEquipped and storage.lgitem then --don't want it to die while waiting for the message
		if itemTemp ~= storage.lgitem then --check if player is still wearing the item
			if storage.lgtechSwapped then
				if storage.lgtechStored then
					player.equipTech(storage.lgtechStored)
				end
				player.makeTechUnavailable(storage.lgtechEquipped)
				if storage.lgdebug then
					local messageTemp = self.radioMessages.received
					messageTemp.text="Item "..storage.lgitem.." removed. Restoring tech "..storage.lgtechStored
					player.radioMessage(messageTemp)
				end
				storage.lgtechSwapped = false
			end
		elseif not player.hasItem({name = storage.lgitem}) then --check if player HAS the item at all
			quest.complete()
		elseif player.equippedTech("legs") ~= storage.lgtechEquipped and storage.lgtechSwapped then --if the tech changed, assume player kinda wants it to change when they take the item off
			storage.lgtechStored = player.equippedTech("legs")
			player.equipTech(storage.lgtechEquipped)
		end
	end
	--[[elseif storage.lgtimer < 120 then --just in case. hope message arrives faster than that.
		storage.lgtimer = storage.lgtimer + dt
	else
		quest.complete()
	end
	quest.setProgress(math.min(1.0,(storage.lgtimer/120)))]]--
end