function init()
  local b = mcontroller.boundBox()
  animator.setParticleEmitterOffsetRegion("jetpackParticles", {b[1], b[2] + 0.2, b[3], b[2] + 0.3})
  self.holdingJump = false
  self.active = false
  jetpackSpeed = config.getParameter("jetpackSpeed")
  jetpackControlForce = config.getParameter("jetpackControlForce")
  energyUsagePerSecond = config.getParameter("energyUsagePerSecond")
end

function input(args)
  if args.moves["jump"] and mcontroller.jumping() then
    self.holdingJump = true
  elseif not args.moves["jump"] then
    self.holdingJump = false
  end

  if args.moves["jump"] and not status.statPositive("activeMovementAbilities") and not mcontroller.canJump() and not self.holdingJump then
    return "jetpack"
  else
    return nil
  end
end

function update(args)
  local action = input(args)

  if action == "jetpack" and status.consumeResource("energy", energyUsagePerSecond * args.dt) then
    animator.setAnimationState("jetpack", "on")
    mcontroller.controlApproachYVelocity(jetpackSpeed, jetpackControlForce)

    if not self.active then
      animator.playSound("activate")
    end
    self.active = true
    animator.setParticleEmitterActive("jetpackParticles", true)
  else
    self.active = false
    animator.setAnimationState("jetpack", "off")
    animator.setParticleEmitterActive("jetpackParticles", false)
  end
end